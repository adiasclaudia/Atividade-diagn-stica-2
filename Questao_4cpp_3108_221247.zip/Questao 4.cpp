#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main (){
    int numero_secreto, palpite;
    numero_secreto = rand() % 100;

    printf("Adivinhe um numero entre 0 e 100: ");
    scanf ("%d",&palpite);

    if (palpite == numero_secreto)
    {
    printf("Parab�ns, voc� acertou!\n");
    }
    else if (palpite > numero_secreto)
    {
    printf("Muito alto, tente um n�mero menor!\n");
    }
    else
    {
    printf("Muito baixo, tente um numero maior!\n");
    }
  
    return 0;
}
