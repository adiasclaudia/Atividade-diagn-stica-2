#include <stdio.h>
#include <locale.h>
int main() {
    int valor;

    printf("Digite o valor do saque: ");
    scanf("%d", &valor);

    if (valor % 2 != 0 && valor % 5 != 0) {
        printf("Erro: valor nao pode ser sacado.\n");
    } else {
        printf("%d nota(s) de 100\n", valor / 100);
        valor %= 100;

        printf("%d nota(s) de 50\n", valor / 50);
        valor %= 50;

        printf("%d nota(s) de 20\n", valor / 20);
        valor %= 20;

        printf("%d nota(s) de 10\n", valor / 10);
        valor %= 10;

        printf("%d nota(s) de 5\n", valor / 5);
        valor %= 5;

        printf("%d nota(s) de 2\n", valor / 2);
    }

    return 0;
}
